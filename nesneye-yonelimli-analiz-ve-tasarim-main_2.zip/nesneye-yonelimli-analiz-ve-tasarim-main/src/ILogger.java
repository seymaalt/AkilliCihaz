
public interface ILogger {
    void log(String mesaj);
}
