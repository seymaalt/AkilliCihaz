
public interface IMerkeziIslemBirimiCihaz {
    void sicaklikOku() throws InterruptedException;

    void sogutucuAc() throws InterruptedException;

    void sogutucuKapat() throws InterruptedException;
}
